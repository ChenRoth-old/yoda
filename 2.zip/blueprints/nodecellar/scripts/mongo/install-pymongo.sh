#!/bin/bash

ctx logger info "Installing pymongo 2.8.0"

pip install pymongo==2.8.0
